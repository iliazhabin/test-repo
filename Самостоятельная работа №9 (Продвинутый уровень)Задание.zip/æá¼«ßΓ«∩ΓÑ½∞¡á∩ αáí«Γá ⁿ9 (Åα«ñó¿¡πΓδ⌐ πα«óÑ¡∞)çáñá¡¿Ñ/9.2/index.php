<?php 
echo "string";
  //Подключаем все наши общие классы: Модель, Контроллер и Представление
  require_once 'core/model.php';
  require_once 'core/view.php';
  require_once 'core/controller.php';
  //Подключаем также Роутинг и запускаем его маршрутизатор
  require_once 'core/route.php';
  Route::start(); // запускаем маршрутизатор 


 ?>